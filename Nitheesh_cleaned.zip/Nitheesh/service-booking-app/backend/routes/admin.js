const express = require('express');
const auth = require('../middleware/auth');
const Provider = require('../models/Provider');
const User = require('../models/User');
const Booking = require('../models/Booking');

const router = express.Router();

// Admin middleware
const adminAuth = (req, res, next) => {
  if (req.user.role !== 'admin' && req.user.id !== 'admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

// Get all providers
router.get('/providers', auth, adminAuth, async (req, res) => {
  try {
    const providers = await Provider.find().select('-password');
    res.json(providers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete provider
router.delete('/providers/:id', auth, adminAuth, async (req, res) => {
  try {
    await Provider.findByIdAndDelete(req.params.id);
    res.json({ message: 'Provider deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Toggle provider status
router.put('/providers/:id/toggle', auth, adminAuth, async (req, res) => {
  try {
    const provider = await Provider.findById(req.params.id);
    provider.isActive = !provider.isActive;
    await provider.save();
    res.json(provider);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get dashboard stats
router.get('/stats', auth, adminAuth, async (req, res) => {
  try {
    const totalProviders = await Provider.countDocuments();
    const totalUsers = await User.countDocuments();
    const totalBookings = await Booking.countDocuments();
    
    const providersByType = await Provider.aggregate([
      { $group: { _id: '$serviceType', count: { $sum: 1 } } }
    ]);

    res.json({
      totalProviders,
      totalUsers,
      totalBookings,
      providersByType
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;