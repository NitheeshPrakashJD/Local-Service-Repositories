const express = require('express');
const auth = require('../middleware/auth');
const Booking = require('../models/Booking');
const Review = require('../models/Review');
const Provider = require('../models/Provider');
const User = require('../models/User');
const { sendBookingNotificationEmail } = require('../config/email');

const router = express.Router();

// Create booking
router.post('/', auth, async (req, res) => {
  try {
    const { provider, date, timeSlot, description } = req.body;
    
    const booking = new Booking({
      user: req.user._id,
      provider,
      date,
      timeSlot,
      description
    });

    await booking.save();
    await booking.populate('provider', 'name serviceType email');
    await booking.populate('user', 'name email');
    
    // Send notification email to provider
    await sendBookingNotificationEmail(
      booking.provider.email,
      booking,
      'new_booking'
    );

    res.status(201).json(booking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user bookings
router.get('/user', auth, async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user._id })
      .populate('provider', 'name serviceType location rating')
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get provider bookings
router.get('/provider', auth, async (req, res) => {
  try {
    const bookings = await Booking.find({ provider: req.user._id })
      .populate('user', 'name email location')
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update booking status
router.put('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    ).populate('user', 'name email').populate('provider', 'name serviceType email');
    
    // Send notification email to user when booking is approved
    if (status === 'approved') {
      await sendBookingNotificationEmail(
        booking.user.email,
        booking,
        'booking_approved'
      );
    }

    res.json(booking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Add review (existing code remains same)
router.post('/:id/review', auth, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    const review = new Review({
      user: req.user._id,
      provider: booking.provider,
      booking: booking._id,
      rating,
      comment
    });

    await review.save();

    // Update provider rating
    const provider = await Provider.findById(booking.provider);
    const reviews = await Review.find({ provider: booking.provider });
    const avgRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;
    
    provider.rating = avgRating;
    provider.totalReviews = reviews.length;
    await provider.save();

    res.status(201).json(review);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;