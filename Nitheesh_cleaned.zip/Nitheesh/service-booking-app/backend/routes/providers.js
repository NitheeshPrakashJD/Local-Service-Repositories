const express = require('express');
const auth = require('../middleware/auth');
const Provider = require('../models/Provider');

const router = express.Router();

// Get all providers
router.get('/', async (req, res) => {
  try {
    const { location, serviceType } = req.query;
    let query = { isActive: true };
    
    if (location) {
      query.location = new RegExp(location, 'i');
    }
    if (serviceType) {
      query.serviceType = serviceType;
    }

    const providers = await Provider.find(query).select('-password');
    res.json(providers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get provider by ID
router.get('/:id', async (req, res) => {
  try {
    const provider = await Provider.findById(req.params.id).select('-password');
    if (!provider) {
      return res.status(404).json({ message: 'Provider not found' });
    }
    res.json(provider);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update provider availability
router.put('/availability', auth, async (req, res) => {
  try {
    const { availability } = req.body;
    const provider = await Provider.findByIdAndUpdate(
      req.user._id,
      { availability },
      { new: true }
    ).select('-password');
    res.json(provider);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;