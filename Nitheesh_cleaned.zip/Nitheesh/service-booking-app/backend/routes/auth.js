const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Provider = require('../models/Provider');
const { sendVerificationEmail, sendPasswordResetEmail } = require('../config/email');

const router = express.Router();

// Register User
router.post('/register/user', async (req, res) => {
  try {
    const { name, email, password, location } = req.body;
    
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const user = new User({ name, email, password, location });
    const verificationToken = user.createVerificationToken();
    await user.save();

    // Send verification email
    await sendVerificationEmail(email, verificationToken, name);

    res.status(201).json({
      message: 'Registration successful! Please check your email to verify your account.',
      userId: user._id
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Register Provider
router.post('/register/provider', async (req, res) => {
  try {
    const { name, email, password, serviceType, serviceDescription, location } = req.body;
    
    const existingProvider = await Provider.findOne({ email });
    if (existingProvider) {
      return res.status(400).json({ message: 'Provider already exists' });
    }

    const provider = new Provider({
      name,
      email,
      password,
      serviceType,
      serviceDescription,
      location
    });
    const verificationToken = provider.createVerificationToken();
    await provider.save();

    // Send verification email
    await sendVerificationEmail(email, verificationToken, name);

    res.status(201).json({
      message: 'Registration successful! Please check your email to verify your account.',
      providerId: provider._id
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Verify Email
router.get('/verify-email/:token', async (req, res) => {
  try {
    const { token } = req.params;

    // Check in both User and Provider collections
    let user = await User.findOne({
      verificationToken: token,
      verificationExpires: { $gt: Date.now() }
    });

    let isProvider = false;
    if (!user) {
      user = await Provider.findOne({
        verificationToken: token,
        verificationExpires: { $gt: Date.now() }
      });
      isProvider = true;
    }

    if (!user) {
      return res.status(400).json({ message: 'Invalid or expired verification token' });
    }

    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationExpires = undefined;
    await user.save();

    const jwtToken = jwt.sign(
      { id: user._id, role: user.role || 'provider' },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      message: 'Email verified successfully!',
      token: jwtToken,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role || 'provider',
        serviceType: user.serviceType,
        isVerified: true
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Check for admin login
    if (role === 'admin' && email === 'admin@admin.com' && password === 'admin123') {
      const adminUser = {
        id: 'admin',
        name: 'Admin',
        email: 'admin@admin.com',
        role: 'admin',
        isVerified: true
      };

      const token = jwt.sign(
        { id: 'admin', role: 'admin' },
        process.env.JWT_SECRET,
        { expiresIn: '30d' }
      );

      return res.json({ token, user: adminUser });
    }

    let user;
    if (role === 'provider') {
      user = await Provider.findOne({ email });
    } else {
      user = await User.findOne({ email });
    }

    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    if (!user.isVerified) {
      return res.status(401).json({ 
        message: 'Please verify your email before logging in',
        needsVerification: true 
      });
    }

    const token = jwt.sign(
      { id: user._id, role: user.role || role },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role || role,
        serviceType: user.serviceType,
        isVerified: user.isVerified
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Forgot Password
router.post('/forgot-password', async (req, res) => {
  try {
    const { email, role } = req.body;

    let user;
    if (role === 'provider') {
      user = await Provider.findOne({ email });
    } else {
      user = await User.findOne({ email });
    }

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const resetToken = user.createPasswordResetToken();
    await user.save();

    await sendPasswordResetEmail(email, resetToken, user.name);

    res.json({ message: 'Password reset email sent successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Reset Password
router.post('/reset-password/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;

    let user = await User.findOne({
      passwordResetToken: token,
      passwordResetExpires: { $gt: Date.now() }
    });

    if (!user) {
      user = await Provider.findOne({
        passwordResetToken: token,
        passwordResetExpires: { $gt: Date.now() }
      });
    }

    if (!user) {
      return res.status(400).json({ message: 'Invalid or expired reset token' });
    }

    user.password = password;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save();

    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Resend Verification Email
router.post('/resend-verification', async (req, res) => {
  try {
    const { email, role } = req.body;

    let user;
    if (role === 'provider') {
      user = await Provider.findOne({ email });
    } else {
      user = await User.findOne({ email });
    }

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.isVerified) {
      return res.status(400).json({ message: 'Email already verified' });
    }

    const verificationToken = user.createVerificationToken();
    await user.save();

    await sendVerificationEmail(email, verificationToken, user.name);

    res.json({ message: 'Verification email sent successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;