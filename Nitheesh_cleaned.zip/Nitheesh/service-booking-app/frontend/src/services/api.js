import axios from 'axios';

export const api = axios.create({
  baseURL: 'http://localhost:5000/api'
});

// Auth API
export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  registerUser: (data) => api.post('/auth/register/user', data),
  registerProvider: (data) => api.post('/auth/register/provider', data),
  verifyEmail: (token) => api.get(`/auth/verify-email/${token}`),
  forgotPassword: (data) => api.post('/auth/forgot-password', data),
  resetPassword: (token, data) => api.post(`/auth/reset-password/${token}`, data),
  resendVerification: (data) => api.post('/auth/resend-verification', data)
};

// Provider API
export const providerAPI = {
  getAll: (params) => api.get('/providers', { params }),
  getById: (id) => api.get(`/providers/${id}`),
  updateAvailability: (data) => api.put('/providers/availability', data)
};

// Booking API
export const bookingAPI = {
  create: (data) => api.post('/bookings', data),
  getUserBookings: () => api.get('/bookings/user'),
  getProviderBookings: () => api.get('/bookings/provider'),
  updateStatus: (id, status) => api.put(`/bookings/${id}/status`, { status }),
  addReview: (id, data) => api.post(`/bookings/${id}/review`, data)
};

// Admin API
export const adminAPI = {
  getProviders: () => api.get('/admin/providers'),
  deleteProvider: (id) => api.delete(`/admin/providers/${id}`),
  toggleProvider: (id) => api.put(`/admin/providers/${id}/toggle`),
  getStats: () => api.get('/admin/stats')
};