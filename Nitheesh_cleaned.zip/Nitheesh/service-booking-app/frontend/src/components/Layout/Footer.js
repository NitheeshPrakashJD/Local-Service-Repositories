import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-content">
          <div className="footer-section">
            <div className="footer-brand">
              <span className="brand-icon">🛠️</span>
              <span className="brand-text">ServiceHub</span>
            </div>
            <p className="footer-description">
              Connecting you with trusted service providers in your area. 
              Book appointments, manage services, and get the help you need.
            </p>
            <div className="social-links">
              <a href="#" className="social-link" aria-label="Facebook">📘</a>
              <a href="#" className="social-link" aria-label="Twitter">🐦</a>
              <a href="#" className="social-link" aria-label="Instagram">📷</a>
              <a href="#" className="social-link" aria-label="LinkedIn">💼</a>
            </div>
          </div>

          <div className="footer-section">
            <h4>For Users</h4>
            <ul className="footer-links">
              <li><Link to="/register">Sign Up</Link></li>
              <li><Link to="/login">Login</Link></li>
              <li><a href="#services">Browse Services</a></li>
              <li><a href="#how-it-works">How It Works</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>For Providers</h4>
            <ul className="footer-links">
              <li><Link to="/register">Join as Provider</Link></li>
              <li><a href="#provider-benefits">Benefits</a></li>
              <li><a href="#provider-guide">Provider Guide</a></li>
              <li><a href="#support">Support</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Services</h4>
            <ul className="footer-links">
              <li><a href="#doctors">🩺 Doctors</a></li>
              <li><a href="#drivers">🚗 Drivers</a></li>
              <li><a href="#plumbers">🔧 Plumbers</a></li>
              <li><a href="#electricians">⚡ Electricians</a></li>
              <li><a href="#maids">🧹 House Cleaning</a></li>
              <li><a href="#carpenters">🔨 Carpenters</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Company</h4>
            <ul className="footer-links">
              <li><a href="#about">About Us</a></li>
              <li><a href="#contact">Contact</a></li>
              <li><a href="#privacy">Privacy Policy</a></li>
              <li><a href="#terms">Terms of Service</a></li>
              <li><a href="#help">Help Center</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Contact Info</h4>
            <div className="contact-info">
              <p>📧 support@servicehub.com</p>
              <p>📞 +1 (555) 123-4567</p>
              <p>📍 Chennai, Tamil Nadu, IN</p>
              <p>🕒 24/7 Customer Support</p>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <div className="footer-bottom-content">
            <p>&copy; 2024 ServiceHub. All rights reserved.</p>
            <div className="footer-bottom-links">
              <a href="#privacy">Privacy</a>
              <a href="#terms">Terms</a>
              <a href="#cookies">Cookies</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;