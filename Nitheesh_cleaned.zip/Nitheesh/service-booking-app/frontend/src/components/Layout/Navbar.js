import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/login');
    setIsMenuOpen(false);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  // Don't show navbar on auth pages
  const hideNavbarPaths = ['/login', '/register', '/forgot-password'];
  const shouldHideNavbar = hideNavbarPaths.includes(location.pathname) || 
                          location.pathname.includes('/verify-email') ||
                          location.pathname.includes('/reset-password');

  if (shouldHideNavbar) return null;

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-brand">
          <span className="brand-icon">🛠️</span>
          <span className="brand-text">ServiceHub</span>
        </Link>

        {user && (
          <>
            <div className={`navbar-menu ${isMenuOpen ? 'active' : ''}`}>
              <div className="navbar-nav">
                <Link 
                  to="/dashboard" 
                  className="nav-link"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <span className="nav-icon">📊</span>
                  Dashboard
                </Link>
                
                {user.role === 'user' && (
                  <>
                    <Link 
                      to="/dashboard" 
                      className="nav-link"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <span className="nav-icon">🔍</span>
                      Find Services
                    </Link>
                    <Link 
                      to="/dashboard" 
                      className="nav-link"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <span className="nav-icon">📝</span>
                      My Bookings
                    </Link>
                  </>
                )}

                {user.role === 'provider' && (
                  <>
                    <Link 
                      to="/dashboard" 
                      className="nav-link"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <span className="nav-icon">📅</span>
                      Calendar
                    </Link>
                    <Link 
                      to="/dashboard" 
                      className="nav-link"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <span className="nav-icon">📋</span>
                      Bookings
                    </Link>
                  </>
                )}

                {user.role === 'admin' && (
                  <Link 
                    to="/dashboard" 
                    className="nav-link"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <span className="nav-icon">👥</span>
                    Manage Users
                  </Link>
                )}
              </div>

              <div className="navbar-user">
                <div className="user-info">
                  <span className="user-avatar">
                    {user.role === 'admin' ? '👨‍💼' : user.role === 'provider' ? '🔧' : '👤'}
                  </span>
                  <div className="user-details">
                    <span className="user-name">{user.name}</span>
                    <span className="user-role">{user.role}</span>
                  </div>
                </div>
                <button onClick={handleLogout} className="logout-btn">
                  <span>🚪</span>
                  Logout
                </button>
              </div>
            </div>

            <button 
              className={`mobile-menu-btn ${isMenuOpen ? 'active' : ''}`}
              onClick={toggleMenu}
            >
              <span></span>
              <span></span>
              <span></span>
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;