import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authAPI } from '../../services/api';
import { toast } from 'react-toastify';

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'user',
    location: '',
    serviceType: '',
    serviceDescription: ''
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let response;
      if (formData.role === 'provider') {
        response = await authAPI.registerProvider(formData);
      } else {
        response = await authAPI.registerUser(formData);
      }
      
      toast.success(response.data.message);
      navigate('/login');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-form register-form">
        <div className="auth-header">
          <h1 className="auth-brand">🛠️ ServiceHub</h1>
          <h2>Join ServiceHub</h2>
          <p>Create your account to get started</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>I want to:</label>
            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              required
            >
              <option value="user">👤 Find Services</option>
              <option value="provider">🔧 Provide Services</option>
            </select>
          </div>

          <div className="form-group">
            <label>Full Name:</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your full name"
              required
            />
          </div>

          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email address"
              required
            />
          </div>

          <div className="form-group">
            <label>Password:</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Create a password (min 6 characters)"
              minLength="6"
              required
            />
          </div>

          <div className="form-group">
            <label>Location:</label>
            <input
              type="text"
              name="location"
              value={formData.location}
              onChange={handleChange}
              placeholder="Enter your city/area"
              required
            />
          </div>

          {formData.role === 'provider' && (
            <>
              <div className="form-group">
                <label>Service Type:</label>
                <select
                  name="serviceType"
                  value={formData.serviceType}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select your service</option>
                  <option value="doctor">🩺 Doctor</option>
                  <option value="maid">🧹 House Cleaning</option>
                  <option value="driver">🚗 Driver</option>
                  <option value="plumber">🔧 Plumber</option>
                  <option value="electrician">⚡ Electrician</option>
                  <option value="carpenter">🔨 Carpenter</option>
                  <option value="other">🛠️ Other</option>
                </select>
              </div>

              <div className="form-group">
                <label>Service Description:</label>
                <textarea
                  name="serviceDescription"
                  value={formData.serviceDescription}
                  onChange={handleChange}
                  placeholder="Describe your services, experience, and expertise..."
                  required
                  rows="4"
                />
              </div>
            </>
          )}

          <button type="submit" disabled={loading} className="btn-primary">
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>

        <div className="auth-links">
          <p className="auth-link">
            Already have an account? <Link to="/login">Sign in here</Link>
          </p>
        </div>

        <div className="auth-note">
          <p>🔒 By creating an account, you agree to our Terms of Service and Privacy Policy. We'll send you a verification email to complete your registration.</p>
        </div>
      </div>
    </div>
  );
};

export default Register;