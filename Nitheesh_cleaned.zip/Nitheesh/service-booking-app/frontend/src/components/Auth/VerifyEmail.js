import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { authAPI } from '../../services/api';
import { toast } from 'react-toastify';

const VerifyEmail = () => {
  const [status, setStatus] = useState('verifying'); // verifying, success, error
  const [message, setMessage] = useState('');
  const { token } = useParams();
  const { login } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const verifyEmail = async () => {
      try {
        const response = await authAPI.verifyEmail(token);
        setStatus('success');
        setMessage(response.data.message);
        
        // Auto login after verification
        login(response.data.token, response.data.user);
        
        toast.success('Email verified successfully!');
        setTimeout(() => {
          navigate('/dashboard');
        }, 2000);
      } catch (error) {
        setStatus('error');
        setMessage(error.response?.data?.message || 'Email verification failed');
        toast.error('Email verification failed');
      }
    };

    if (token) {
      verifyEmail();
    }
  }, [token, login, navigate]);

  return (
    <div className="auth-container">
      <div className="auth-form verify-email-form">
        <div className="verify-header">
          <span className="verify-icon">
            {status === 'verifying' && '⏳'}
            {status === 'success' && '✅'}
            {status === 'error' && '❌'}
          </span>
          <h2>
            {status === 'verifying' && 'Verifying Email...'}
            {status === 'success' && 'Email Verified!'}
            {status === 'error' && 'Verification Failed'}
          </h2>
        </div>

        <div className="verify-content">
          <p className={`verify-message ${status}`}>
            {status === 'verifying' && 'Please wait while we verify your email address...'}
            {message}
          </p>

          {status === 'success' && (
            <div className="success-actions">
              <p className="redirect-message">
                🎉 Welcome to ServiceHub! Redirecting to your dashboard...
              </p>
              <div className="loading-spinner"></div>
            </div>
          )}

          {status === 'error' && (
            <div className="error-actions">
              <Link to="/login" className="btn-primary">
                Back to Login
              </Link>
              <p className="help-text">
                Need help? <a href="mailto:support@servicehub.com">Contact Support</a>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VerifyEmail;