import React, { useState } from 'react';
import { bookingAPI } from '../../services/api';
import ReviewForm from '../Review/ReviewForm';

const BookingHistory = ({ bookings, onRefresh }) => {
  const [showReviewForm, setShowReviewForm] = useState(null);

  const handleReviewSubmit = async (bookingId, reviewData) => {
    try {
      await bookingAPI.addReview(bookingId, reviewData);
      setShowReviewForm(null);
      onRefresh();
    } catch (error) {
      console.error('Error submitting review:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return '#ffa500';
      case 'approved': return '#00ff00';
      case 'rejected': return '#ff0000';
      case 'completed': return '#0000ff';
      default: return '#666';
    }
  };

  if (bookings.length === 0) {
    return <div className="no-bookings">No bookings yet.</div>;
  }

  return (
    <div className="booking-history">
      <h2>My Bookings</h2>
      <div className="bookings-list">
        {bookings.map(booking => (
          <div key={booking._id} className="booking-card">
            <div className="booking-info">
              <h3>{booking.provider.name}</h3>
              <p><strong>Service:</strong> {booking.provider.serviceType}</p>
              <p><strong>Date:</strong> {booking.date}</p>
              <p><strong>Time:</strong> {booking.timeSlot}</p>
              <p><strong>Location:</strong> {booking.provider.location}</p>
              <p><strong>Description:</strong> {booking.description}</p>
              <p>
                <strong>Status:</strong>
                <span style={{ color: getStatusColor(booking.status), marginLeft: '5px' }}>
                  {booking.status.toUpperCase()}
                </span>
              </p>
            </div>
            
            {booking.status === 'completed' && (
              <div className="booking-actions">
                <button
                  onClick={() => setShowReviewForm(booking._id)}
                  className="btn-primary"
                >
                  Write Review
                </button>
              </div>
            )}

            {showReviewForm === booking._id && (
              <ReviewForm
                booking={booking}
                onSubmit={(reviewData) => handleReviewSubmit(booking._id, reviewData)}
                onCancel={() => setShowReviewForm(null)}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookingHistory;