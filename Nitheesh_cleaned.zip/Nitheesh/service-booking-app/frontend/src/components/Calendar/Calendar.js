import React, { useState } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

const CalendarComponent = ({ bookings }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());

  const getBookingsForDate = (date) => {
    const dateString = date.toISOString().split('T')[0];
    return bookings.filter(booking => booking.date === dateString);
  };

  const tileContent = ({ date, view }) => {
    if (view === 'month') {
      const dayBookings = getBookingsForDate(date);
      if (dayBookings.length > 0) {
        return (
          <div className="calendar-booking-indicator">
            <span className="booking-count">{dayBookings.length}</span>
          </div>
        );
      }
    }
    return null;
  };

  const tileClassName = ({ date, view }) => {
    if (view === 'month') {
      const dayBookings = getBookingsForDate(date);
      if (dayBookings.length > 0) {
        return 'has-bookings';
      }
    }
    return null;
  };

  const selectedDateBookings = getBookingsForDate(selectedDate);

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return '#ffa500';
      case 'approved': return '#28a745';
      case 'rejected': return '#dc3545';
      case 'completed': return '#007bff';
      default: return '#6c757d';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending': return '⏳';
      case 'approved': return '✅';
      case 'rejected': return '❌';
      case 'completed': return '🎉';
      default: return '📝';
    }
  };

  const formatTime = (timeSlot) => {
    return timeSlot;
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Get upcoming bookings (next 7 days)
  const getUpcomingBookings = () => {
    const today = new Date();
    const nextWeek = new Date();
    nextWeek.setDate(today.getDate() + 7);
    
    return bookings.filter(booking => {
      const bookingDate = new Date(booking.date);
      return bookingDate >= today && bookingDate <= nextWeek && booking.status === 'approved';
    }).sort((a, b) => new Date(a.date) - new Date(b.date));
  };

  const upcomingBookings = getUpcomingBookings();

  // Get monthly stats
  const getMonthlyStats = () => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const monthlyBookings = bookings.filter(booking => {
      const bookingDate = new Date(booking.date);
      return bookingDate.getMonth() === currentMonth && bookingDate.getFullYear() === currentYear;
    });

    return {
      total: monthlyBookings.length,
      pending: monthlyBookings.filter(b => b.status === 'pending').length,
      approved: monthlyBookings.filter(b => b.status === 'approved').length,
      completed: monthlyBookings.filter(b => b.status === 'completed').length,
      rejected: monthlyBookings.filter(b => b.status === 'rejected').length
    };
  };

  const monthlyStats = getMonthlyStats();

  return (
    <div className="calendar-container">
      <div className="calendar-header">
        <h2>My Calendar</h2>
        <div className="calendar-stats">
          <div className="stat-item">
            <span className="stat-number">{monthlyStats.total}</span>
            <span className="stat-label">Total This Month</span>
          </div>
          <div className="stat-item">
            <span className="stat-number">{monthlyStats.pending}</span>
            <span className="stat-label">Pending</span>
          </div>
          <div className="stat-item">
            <span className="stat-number">{monthlyStats.approved}</span>
            <span className="stat-label">Approved</span>
          </div>
          <div className="stat-item">
            <span className="stat-number">{monthlyStats.completed}</span>
            <span className="stat-label">Completed</span>
          </div>
        </div>
      </div>

      <div className="calendar-view">
        <div className="calendar-main">
          <Calendar
            onChange={setSelectedDate}
            value={selectedDate}
            tileContent={tileContent}
            tileClassName={tileClassName}
            className="provider-calendar"
            minDate={new Date()}
            showNeighboringMonth={false}
          />
          
          <div className="calendar-legend">
            <h4>Legend:</h4>
            <div className="legend-items">
              <div className="legend-item">
                <div className="legend-color" style={{backgroundColor: '#667eea'}}></div>
                <span>Has Bookings</span>
              </div>
              <div className="legend-item">
                <div className="legend-color" style={{backgroundColor: '#28a745'}}></div>
                <span>Selected Date</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="calendar-sidebar">
          <div className="selected-date-bookings">
            <h3>
              <span className="calendar-icon">📅</span>
              {formatDate(selectedDate)}
            </h3>
            
            {selectedDateBookings.length === 0 ? (
              <div className="no-bookings-day">
                <div className="empty-state">
                  <span className="empty-icon">🗓️</span>
                  <p>No bookings for this date</p>
                  <small>Select a different date to view bookings</small>
                </div>
              </div>
            ) : (
              <div className="day-bookings">
                {selectedDateBookings.map(booking => (
                  <div key={booking._id} className="day-booking">
                    <div className="booking-time">
                      <span className="time-icon">🕐</span>
                      {formatTime(booking.timeSlot)}
                    </div>
                    <div className="booking-details">
                      <div className="customer-info">
                        <h4>{booking.user.name}</h4>
                        <p className="customer-email">{booking.user.email}</p>
                      </div>
                      {booking.description && (
                        <p className="booking-description">"{booking.description}"</p>
                      )}
                      <div className="booking-meta">
                        <span 
                          className={`status ${booking.status}`}
                          style={{ borderLeft: `4px solid ${getStatusColor(booking.status)}` }}
                        >
                          {getStatusIcon(booking.status)} {booking.status.toUpperCase()}
                        </span>
                        {booking.user.location && (
                          <span className="location">
                            📍 {booking.user.location}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {upcomingBookings.length > 0 && (
            <div className="upcoming-bookings">
              <h3>
                <span className="upcoming-icon">⏰</span>
                Upcoming This Week
              </h3>
              <div className="upcoming-list">
                {upcomingBookings.slice(0, 5).map(booking => (
                  <div key={booking._id} className="upcoming-booking">
                    <div className="upcoming-date">
                      {new Date(booking.date).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric'
                      })}
                    </div>
                    <div className="upcoming-details">
                      <div className="upcoming-time">{booking.timeSlot}</div>
                      <div className="upcoming-customer">{booking.user.name}</div>
                    </div>
                    <div className="upcoming-status">
                      {getStatusIcon(booking.status)}
                    </div>
                  </div>
                ))}
              </div>
              {upcomingBookings.length > 5 && (
                <div className="more-bookings">
                  +{upcomingBookings.length - 5} more bookings
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CalendarComponent;