import React from 'react';
import ProviderCard from './ProviderCard';

const ProviderList = ({ providers, loading, onBookProvider }) => {
  if (loading) {
    return <div className="loading">Loading providers...</div>;
  }

  if (providers.length === 0) {
    return <div className="no-results">No providers found in your area.</div>;
  }

  return (
    <div className="providers-grid">
      {providers.map(provider => (
        <ProviderCard
          key={provider._id}
          provider={provider}
          onBook={onBookProvider}
        />
      ))}
    </div>
  );
};

export default ProviderList;