import React from 'react';

const ProviderCard = ({ provider, onBook }) => {
  return (
    <div className="provider-card">
      <div className="provider-header">
        <h3>{provider.name}</h3>
        <span className="service-type">{provider.serviceType}</span>
      </div>
      <div className="provider-details">
        <p><strong>Location:</strong> {provider.location}</p>
        <p><strong>Description:</strong> {provider.serviceDescription}</p>
        <div className="rating">
          <span>⭐ {provider.rating.toFixed(1)}</span>
          <span>({provider.totalReviews} reviews)</span>
        </div>
      </div>
      <button
        onClick={() => onBook(provider)}
        className="btn-primary"
      >
        Book Now
      </button>
    </div>
  );
};

export default ProviderCard;