import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { providerAPI, bookingAPI } from '../../services/api';
import ProviderList from '../Provider/ProviderList';
import BookingHistory from '../Booking/BookingHistory';
import BookingForm from '../Booking/BookingForm';

const UserDashboard = () => {
  const [activeTab, setActiveTab] = useState('providers');
  const [providers, setProviders] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [loading, setLoading] = useState(false);
  const [searchFilters, setSearchFilters] = useState({
    location: '',
    serviceType: ''
  });

  const { user, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchProviders();
    fetchBookings();
  }, []);

  const fetchProviders = async () => {
    try {
      setLoading(true);
      const response = await providerAPI.getAll(searchFilters);
      setProviders(response.data);
    } catch (error) {
      console.error('Error fetching providers:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchBookings = async () => {
    try {
      const response = await bookingAPI.getUserBookings();
      setBookings(response.data);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    }
  };

  const handleSearch = () => {
    fetchProviders();
  };

  const handleBookProvider = (provider) => {
    setSelectedProvider(provider);
    setActiveTab('book');
  };

  const handleBookingSuccess = () => {
    setSelectedProvider(null);
    setActiveTab('bookings');
    fetchBookings();
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Welcome, {user.name}!</h1>
        <button onClick={handleLogout} className="btn-secondary">Logout</button>
      </header>

      <nav className="dashboard-nav">
        <button
          className={activeTab === 'providers' ? 'active' : ''}
          onClick={() => setActiveTab('providers')}
        >
          Find Providers
        </button>
        <button
          className={activeTab === 'bookings' ? 'active' : ''}
          onClick={() => setActiveTab('bookings')}
        >
          My Bookings
        </button>
        {selectedProvider && (
          <button
            className={activeTab === 'book' ? 'active' : ''}
            onClick={() => setActiveTab('book')}
          >
            Book Service
          </button>
        )}
      </nav>

      <main className="dashboard-content">
        {activeTab === 'providers' && (
          <div>
            <div className="search-filters">
              <input
                type="text"
                placeholder="Search by location"
                value={searchFilters.location}
                onChange={(e) => setSearchFilters({...searchFilters, location: e.target.value})}
              />
              <select
                value={searchFilters.serviceType}
                onChange={(e) => setSearchFilters({...searchFilters, serviceType: e.target.value})}
              >
                <option value="">All Services</option>
                <option value="doctor">Doctor</option>
                <option value="maid">Maid</option>
                <option value="driver">Driver</option>
                <option value="plumber">Plumber</option>
                <option value="electrician">Electrician</option>
                <option value="carpenter">Carpenter</option>
                <option value="other">Other</option>
              </select>
              <button onClick={handleSearch} className="btn-primary">Search</button>
            </div>
            <ProviderList 
              providers={providers} 
              loading={loading}
              onBookProvider={handleBookProvider}
            />
          </div>
        )}

        {activeTab === 'bookings' && (
          <BookingHistory bookings={bookings} onRefresh={fetchBookings} />
        )}

        {activeTab === 'book' && selectedProvider && (
          <BookingForm
            provider={selectedProvider}
            onSuccess={handleBookingSuccess}
            onCancel={() => {
              setSelectedProvider(null);
              setActiveTab('providers');
            }}
          />
        )}
      </main>
    </div>
  );
};

export default UserDashboard;