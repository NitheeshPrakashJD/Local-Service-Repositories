import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { bookingAPI } from '../../services/api';
import Calendar from '../Calendar/Calendar';

const ProviderDashboard = () => {
  const [activeTab, setActiveTab] = useState('bookings');
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);

  const { user, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      setLoading(true);
      const response = await bookingAPI.getProviderBookings();
      setBookings(response.data);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (bookingId, status) => {
    try {
      await bookingAPI.updateStatus(bookingId, status);
      fetchBookings();
    } catch (error) {
      console.error('Error updating booking status:', error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const pendingBookings = bookings.filter(b => b.status === 'pending');
  const confirmedBookings = bookings.filter(b => b.status === 'approved');

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Welcome, {user.name}!</h1>
        <p>Service: {user.serviceType}</p>
        <button onClick={handleLogout} className="btn-secondary">Logout</button>
      </header>

      <nav className="dashboard-nav">
        <button
          className={activeTab === 'bookings' ? 'active' : ''}
          onClick={() => setActiveTab('bookings')}
        >
          Booking Requests
        </button>
        <button
          className={activeTab === 'calendar' ? 'active' : ''}
          onClick={() => setActiveTab('calendar')}
        >
          Calendar
        </button>
      </nav>

      <main className="dashboard-content">
        {activeTab === 'bookings' && (
          <div>
            <h2>Pending Requests ({pendingBookings.length})</h2>
            {loading ? (
              <p>Loading...</p>
            ) : pendingBookings.length === 0 ? (
              <p>No pending booking requests</p>
            ) : (
              <div className="bookings-list">
                {pendingBookings.map(booking => (
                  <div key={booking._id} className="booking-card pending">
                    <div className="booking-info">
                      <h3>{booking.user.name}</h3>
                      <p>Email: {booking.user.email}</p>
                      <p>Date: {booking.date}</p>
                      <p>Time: {booking.timeSlot}</p>
                      <p>Description: {booking.description}</p>
                      <p>Location: {booking.user.location}</p>
                    </div>
                    <div className="booking-actions">
                      <button
                        onClick={() => handleStatusUpdate(booking._id, 'approved')}
                        className="btn-success"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => handleStatusUpdate(booking._id, 'rejected')}
                        className="btn-danger"
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <h2>Confirmed Bookings ({confirmedBookings.length})</h2>
            <div className="bookings-list">
              {confirmedBookings.map(booking => (
                <div key={booking._id} className="booking-card confirmed">
                  <div className="booking-info">
                    <h3>{booking.user.name}</h3>
                    <p>Email: {booking.user.email}</p>
                    <p>Date: {booking.date}</p>
                    <p>Time: {booking.timeSlot}</p>
                    <p>Description: {booking.description}</p>
                    <p>Status: {booking.status}</p>
                  </div>
                  <div className="booking-actions">
                    <button
                      onClick={() => handleStatusUpdate(booking._id, 'completed')}
                      className="btn-primary"
                      disabled={booking.status === 'completed'}
                    >
                      {booking.status === 'completed' ? 'Completed' : 'Mark Complete'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'calendar' && (
          <Calendar bookings={confirmedBookings} />
        )}
      </main>
    </div>
  );
};

export default ProviderDashboard;