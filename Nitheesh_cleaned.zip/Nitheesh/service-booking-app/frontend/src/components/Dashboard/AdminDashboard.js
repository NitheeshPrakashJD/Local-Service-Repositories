import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { adminAPI } from '../../services/api';

const AdminDashboard = () => {
  const [providers, setProviders] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(false);

  const { logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchProviders();
    fetchStats();
  }, []);

  const fetchProviders = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getProviders();
      setProviders(response.data);
    } catch (error) {
      console.error('Error fetching providers:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await adminAPI.getStats();
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleDeleteProvider = async (providerId) => {
    if (window.confirm('Are you sure you want to delete this provider?')) {
      try {
        await adminAPI.deleteProvider(providerId);
        fetchProviders();
        fetchStats();
      } catch (error) {
        console.error('Error deleting provider:', error);
      }
    }
  };

  const handleToggleProvider = async (providerId) => {
    try {
      await adminAPI.toggleProvider(providerId);
      fetchProviders();
    } catch (error) {
      console.error('Error toggling provider status:', error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Admin Dashboard</h1>
        <button onClick={handleLogout} className="btn-secondary">Logout</button>
      </header>

      <div className="admin-stats">
        <div className="stat-card">
          <h3>Total Users</h3>
          <p>{stats.totalUsers || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Total Providers</h3>
          <p>{stats.totalProviders || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Total Bookings</h3>
          <p>{stats.totalBookings || 0}</p>
        </div>
      </div>

      <div className="provider-stats">
        <h2>Providers by Service Type</h2>
        <div className="service-stats">
          {stats.providersByType?.map(item => (
            <div key={item._id} className="service-stat">
              <span>{item._id}: {item.count}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="providers-management">
        <h2>Manage Providers</h2>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <div className="providers-list">
            {providers.map(provider => (
              <div key={provider._id} className="provider-card">
                <div className="provider-info">
                  <h3>{provider.name}</h3>
                  <p>Email: {provider.email}</p>
                  <p>Service: {provider.serviceType}</p>
                  <p>Location: {provider.location}</p>
                  <p>Rating: {provider.rating.toFixed(1)} ({provider.totalReviews} reviews)</p>
                  <p>Status: {provider.isActive ? 'Active' : 'Inactive'}</p>
                </div>
                <div className="provider-actions">
                  <button
                    onClick={() => handleToggleProvider(provider._id)}
                    className={provider.isActive ? 'btn-warning' : 'btn-success'}
                  >
                    {provider.isActive ? 'Deactivate' : 'Activate'}
                  </button>
                  <button
                    onClick={() => handleDeleteProvider(provider._id)}
                    className="btn-danger"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;